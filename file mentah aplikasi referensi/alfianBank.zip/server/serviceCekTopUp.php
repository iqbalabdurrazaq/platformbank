<?php

    require_once "koneksi.php";
    $z = new db();
    
    $tampung=$_GET["kodee"];
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$sql = "select * from pembayaran_topup_frstore where kode_transfer_saldo='$tampung'";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_cekPembayaran/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kodee=$xml->addChild("id_topup",$row["id_topup"]);
	    $kodee->addAttribute("kode_transfer_saldo",$row["kode_transfer_saldo"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>