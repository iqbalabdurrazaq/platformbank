<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'id5599999_sahbank');    // DB username
define('DB_PASSWORD', 'sahbank123');    // DB password
define('DB_DATABASE', 'id5599999_sahbank');      // DB name
$db = mysqli_connect('localhost', 'id5599999_sahbank', '', 'id5599999_sahbank') or die( "Unable to connect");
// $database = mysqli_select_db(DB_DATABASE) or die( "Unable to select database");
?>