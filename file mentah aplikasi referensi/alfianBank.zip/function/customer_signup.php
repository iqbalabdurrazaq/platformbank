<?php

	include('db/dbconn.php');
	if (isset($_POST['signup']))
{
    $no_rekening=$_POST['no_rekening'];
	$nama=$_POST['nama'];
	$alamat=$_POST['alamat'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$query = $conn->query("SELECT * FROM `data` WHERE `email` = '$email'");
	$check = $query->num_rows;
		if($check == 1)
			{
				echo "<script>alert('EMAIL ALREADY EXIST')</script>";	 
			}
			
			else
				{
					$conn->query ("INSERT INTO data (no_rekening, nama, alamat, email, password)
					VALUES ('$no_rekening', '$nama', '$alamat', '$email', '$password')") 
					or die(mysqli_error());	
				}				
					
}
?>