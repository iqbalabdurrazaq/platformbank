<?php
class db
{
	public $server = "localhost";
	public $username = "id5599999_sahbank";
	public $password = "sahbank123";
	public $database = "id5599999_sahbank";

	public $host_data = "http://alfiaansaputra.000webhostapp.com/";
}
?>
