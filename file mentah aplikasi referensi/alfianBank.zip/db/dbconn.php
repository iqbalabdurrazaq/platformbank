<?php
	$conn = new mysqli('localhost', 'id5599999_sahbank', 'sahbank123', 'id5599999_sahbank');
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}

?>
