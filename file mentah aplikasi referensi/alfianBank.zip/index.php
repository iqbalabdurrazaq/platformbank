<?php 
	include("function/login.php");
	include("function/customer_signup.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>E-BANKING</title>
	<link rel="icon" href="" />
	<link rel = "stylesheet" type = "text/css" href="tambahan_css/style.css" media="all">
	<link rel="stylesheet" type="text/css" href="tambahan_css/bootstrap.css">
	<script src="tambahan_js/bootstrap.js"></script>
	<script src="tambahan_js/jquery-1.7.2.min.js"></script>
	<script src="tambahan_js/carousel.js"></script>
	<script src="tambahan_js/button.js"></script>
	<script src="tambahan_js/dropdown.js"></script>
	<script src="tambahan_js/tab.js"></script>
	<script src="tambahan_js/tooltip.js"></script>
	<script src="tambahan_js/popover.js"></script>
	<script src="tambahan_js/collapse.js"></script>
	<script src="tambahan_js/modal.js"></script>
	<script src="tambahan_js/scrollspy.js"></script>
	<script src="tambahan_js/alert.js"></script>
	<script src="tambahan_js/transition.js"></script>
	<script src="tambahan_js/bootstrap.min.js"></script>
</head>
<body>
	<div id="header">
		<img src="img/logo.jpg">
		<label>SAHBANK</label>
			<ul>
				<li><a href="#signup"   data-toggle="modal">Sign Up</a></li>
				<li><a href="#login"   data-toggle="modal">Login</a></li>
			</ul>
	</div>
		<div id="login" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:400px;">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
				<h3 id="myModalLabel">Login...</h3>
			</div>
				<div class="modal-body">
					<form method="post">
					<center>
						<input type="email" name="email" placeholder="Email" style="width:250px;">
						<input type="password" name="password" placeholder="Password" style="width:250px;">
					</center>
				</div>
			<div class="modal-footer">
				<input class="btn btn-primary" type="submit" name="login" value="Login">
				<button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Close</button>
					</form>
			</div>
		</div>
		<div id="signup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:700px;">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Sign Up Here...</h3>
				</div>
					<div class="modal-body">
						<center>
					<form method="post
					    <input type="text" name="no rekening" placeholder="No Rekening" required>
						<input type="text" name="nama" placeholder="Nama" required>
						<input type="text" name="alamat" placeholder="Alamat" style="width:430px;"required>
						<input type="email" name="email" placeholder="Email" required>
						<input type="password" name="password" placeholder="Password" required>
						</center>
					</div>
				<div class="modal-footer">
					<input type="submit" class="btn btn-primary" name="signup" value="Sign Up">
					<button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Close</button>
				</div>
					</form>
			</div>
</body>
</html>