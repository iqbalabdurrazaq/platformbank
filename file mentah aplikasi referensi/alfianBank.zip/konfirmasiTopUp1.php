<?php
    error_reporting(E_ERROR | E_PARSE);
    
    $kode_top_up=$_GET["kode_top_up"];
    $topup=$_GET["topup"];
    $email=$_GET["email"];
    
    $curl = curl_init();
    curl_setopt($curl , CURLOPT_URL, "http://farrasmuttaqin1.000webhostapp.com/server/serviceOkTopUp.php?kode_top_up=$kode_top_up&topup=$topup&email=$email");
    curl_setopt($curl , CURLOPT_HEADER,0);
    curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
    $xml = new SimpleXMLElement(curl_exec($curl));
    curl_close($curl);
    
    $nm=0;
    foreach($xml->kode as $kode) :
    	$nm=$kode;
    endforeach;
    
    if($nm==0)
    {
       header('Location: konfirmasiTopUp.php?tampung=0');
    }
    else
    {
      require_once "koneksi.php";
      $z = new db();
      $conn = mysqli_connect($z->server,$z->username,$z->password,$z->database);
      $date = date('d/m/Y');
        $sql = "INSERT INTO pembayaran_topup_frstore(kode_transfer_saldo,jumlah_top_up,email,tanggal_transfer) VALUES('$kode_top_up','$topup','$email','$date')";
                                        
       $result = mysqli_query($conn, $sql);
            
            $conn->close();
            
             header('Location: konfirmasiTopUp.php?tampung=1');
    
     
       
    }
?>