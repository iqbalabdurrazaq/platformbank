<?php
	include("http://"+server+"/server/config.php");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   		$pin = mysqli_real_escape_string($db,$_POST['pin']);
     	$password = mysqli_real_escape_string($db,$_POST['password']); 
    	$sql = "SELECT * FROM data WHERE pin = '$pin' and password = '$password'";
      	$result = mysqli_query($db,$sql);
      	$numResult = mysqli_num_rows($result);
      	if($numResult > 0){
			$row = mysqli_fetch_array($result);
		//	$Status = $xml->addChild("Status", "Sukses Login");
			$_SESSION['nopin'] = $row['pin'];
	        $_SESSION['pass'] = $row['password']; 
	        $_SESSION['no_rek'] = $row['no_rekening']; 
	        $_SESSION['nama_pemilik'] = $row['nama']; 
	        header("location: ../sister_client/menu.php");
      	} else {
      		echo "<script>alert('Your login name or password is invalid'); window.location = '../sister_client/index.php'</script>";
      	//	$Status = $xml->addChild("Status", "Gagal Login");
   //    		echo '<script language="javascript">';
			// echo 'alert("Your Login Name or Password is invalid")';
			// echo '</script>';
			// header("location: ../sister_client/index.php");
      	}
   }
?>