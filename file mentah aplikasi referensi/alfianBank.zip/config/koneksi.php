<?php
class db
{
	public $server = "localhost";
	public $username = "id5599999_sahbank";
	public $password = "";
	public $database = "id5599999_sahbank";

	public $host_data = "http://alfiaansaputra.000webhostapp.com/";
}
?>
