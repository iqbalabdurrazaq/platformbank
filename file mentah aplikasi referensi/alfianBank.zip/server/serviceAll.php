<?php

    require_once "koneksi.php";
    $z = new db();

    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$sql = "select * from pembayaran";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_cekPembayaran/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kodee=$xml->addChild("kodee",$row["kode_transfer"]);
	    $kodee->addAttribute("invoice",$row["nomor_invoice"]);
	    $kodee->addAttribute("total",$row["total_bayar"]);
	    $kodee->addAttribute("nama",$row["nama"]);
	    $kodee->addAttribute("email",$row["email"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>